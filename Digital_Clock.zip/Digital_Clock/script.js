function digitalclock() {
  const now = new Date();

  const hours = now.getHours();
  const meridiem = hours >= 12 ? "PM" : "AM";
  const minutes = now.getMinutes().toString().padStart(2, 0);
  const seconds = now.getSeconds().toString().padStart(2, 0);

  const displaytime = `${hours}:${minutes}:${seconds} ${meridiem}`;
  document.getElementById("clock").innerHTML = displaytime;
}

digitalclock();
setInterval(digitalclock, 1000);
